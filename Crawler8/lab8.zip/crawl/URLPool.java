package crawl;

import java.net.*;
import java.util.*;

public class URLPool{
	private List<URLDepthPair> pool;

	public URLPool(URLDepthPair url){
		this.pool = new LinkedList<URLDepthPair>();
		this.pool.add(url);
	}
	public URLPool(){
		this.pool = new LinkedList<URLDepthPair>();
	}

	public boolean isEmpty(){
		return pool.isEmpty();	
	}
	public void showPool(){
		for (URLDepthPair url : this.pool){
			System.out.println(url.toString());
		}
	}
	public synchronized void add(URLDepthPair url){
		pool.add(url);
		
	}
	public synchronized URLDepthPair getNewURL() throws InterruptedException{
		if (!this.pool.isEmpty()){
			return this.pool.remove(0);
		}
		else return null;
	}

}